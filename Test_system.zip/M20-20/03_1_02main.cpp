#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "03_1_02.h"

int main(int argc, char *argv[])
{
	char filename [256];
	if (argc>1)
	{
		task_03_1_02 (argv[1]);
	}
	else
	{
		scanf ("%s", filename);
		task_03_1_02(filename);
	}
	return 0;
}