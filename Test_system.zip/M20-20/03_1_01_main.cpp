#include <stdlib.h>
#include <stdio.h>
using namespace std;

int main(){
	FILE *fm;
	fm=fopen("03_1_01.txt", "w");
	fprintf(fm,"%d",888);
	fclose(fm);
	return 0;
}