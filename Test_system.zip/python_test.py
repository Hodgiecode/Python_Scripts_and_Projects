import os
import subprocess

def extract_code(str1):
    s=""
    for i in range(len(str1)):
        if not str1[i].isdigit() and not str1[i]=="-" and not str1[i]=="_":
            break
        
        s=s+str1[i]

    if s[-1]=="_":
        s=s[:-1]
        
    return s

def find_outfile(code):
     a=os.scandir()
     for x in a:
         if code in x.name and ".txt" in x.name:
             return x.name

     return ""
    

def read(filedir):
    a=os.scandir(filedir)
    file_list=[]
   
    for x in a:
        mode=0
        
        if not "." in x.name: ##проверка на директорию
            continue

        y=extract_code(x.name)
        for i in range(len(file_list)):
            if file_list[i][0]==y:
                mode=1
                file_list[i].append(x.name)
                break

        if mode==0:
            file_list.append([y,x.name])
                
    return file_list

def create_makefile_and_run(data,dir_):
    #template='all:\n\tgcc -W -Wall -Wfloat-equal -Wpointer-arith -Wwrite-strings -Wcast-align -Wformat-security -Wmissing-format-attribute -Wformat=1 -Wno-long-long -Wcast-align -Winline -Werror -pedantic -pedantic-errors -std=gnu99 -Wstrict-prototypes -Wmissing-prototypes -Wmissing-declarations -Wold-style-definition -Wdeclaration-after-statement -Wbad-function-cast -Wnested-externs -Wunused -Wuninitialized -fPIC -o '

    template="all:\n\tg++ -o "
    f=open("makefile","w",encoding="utf-8")
    f.write(template+" "+data[0])
    for i in range(1,len(data)):
        f.write(" "+dir_+"/"+data[i])
    f.close()

    try:
        output= subprocess.check_output("make -f makefile", shell=True)
    except Exception as e:
        return 'Ошибка при компиляции\n'+str(e.output.decode)+'\n'

    test=extract_code(data[0])[3:]
    s=""
    for i in range(2):
        in_f="tests/"+test+"-"+str(i+1)+".in"
        try:
            output = subprocess.check_output(data[0]+".exe "+in_f, shell=True)
        except Exception as e:
            return 'Ошибка при при подаче теста '+in_f+'\n'+str(e)

        result_p=[]
        out=find_outfile(extract_code(data[0]))
        if out=="":
            return 'Не найден выходной файл '+data[0]+'\n'
        
        f=open(out,"r",encoding="utf-8")
        for line in f:
            result_p.append(line)
        f.close()

        result_t=[]
        print("tests/"+test+"-"+str(i+1)+".out")
        f=open("tests/"+test+"-"+str(i+1)+".out","r",encoding="utf-8")
        for line in f:
            result_t.append(line)
        f.close()

        if result_p==result_t:
            s=s+"tests/"+test+"-"+str(i+1)+": PASSED\n"
        else:
            s=s+"tests/"+test+"-"+str(i+1)+": FAILED\n"

        s=s+'Ожидаемый результат: '+str(result_t)+'\n'+'Полученный результат: '+str(result_p)+'\n'
       
    a=os.scandir()

    for x in a:
        y=x.name
        if data[0] in y:
            os.remove(y)
   
    return s
   
def main():
    a=read("M20-20")
    r=[]

    print('Compile')
    for i in range(len(a)):
        b=create_makefile_and_run(a[i],"M20-20")
        r.append(b)

    print('Print to log.txt')
    f=open("log.txt","w",encoding="utf-8")
    for x in r:
        f.write(x)
        f.write('\n')
    f.close()
    
    print('Finish')
    
main()



