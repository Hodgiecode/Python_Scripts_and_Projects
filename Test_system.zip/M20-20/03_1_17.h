#pragma warning(disable:4996)
int task_03_1_17(char *filename);