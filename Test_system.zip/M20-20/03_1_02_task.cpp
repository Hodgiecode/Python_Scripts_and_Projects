#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int 03_1_02_SA (double *otv)
{
	int err=0, i=2;
	double a, b;  

	FILE *FILE, *fm;

	FILE=fopen("03_1_02_in.txt", "r");

	fm=fopen("03_1_02_out.txt", "w");
	
	if (FILE==NULL)
		return -2;

	else if(fscanf(FILE , "%lf", &b)!=1)
		        return -1;

	else if(fscanf(FILE , "%lf", &a)!=1)
	{
		 fprintf (fm, "%lf\n", b);
		return 0;
	}

	else 
	{
		a=a+b;
		while(fscanf(FILE, "%lf", &b)==1)
		{
			i++;
			a=a+b;
		}
		a=a/i;
		fprintf (fm, "%lf\n", a);
	}

	fclose (FILE);
	fclose (fm);
	return err;
}