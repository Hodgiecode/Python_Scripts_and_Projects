#pragma warning (disable:4996)
int task_03_1_01_SandP (double *otv1, double *otv2);