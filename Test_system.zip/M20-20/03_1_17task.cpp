#include <stdio.h>
#include "03_1_17.h"

int task_03_1_17(char *filename){
  int err = -1;
  int kol = 0, b = 0;
  float a, tmp_a;
  FILE *fr, *fw;
  fr = fopen(filename, "r");
  fw = fopen("03_1_17out.txt", "w");
  if (fr != NULL){
    err = 0;
    if (fscanf(fr, "%f", &tmp_a) == 1);
    while (fscanf(fr, "%f", &a) == 1){
      if (tmp_a == a){
        if (b == 0){
          kol++;
          b = 1;
        }
      }
      else
        b = 0;
      tmp_a = a;
    }
    fclose(fr);
    fprintf(fw, "%d",kol);
  }
  fclose(fw);
  return err;
}