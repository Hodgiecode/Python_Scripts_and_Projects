import datetime
import pandas as pd
import os
import pytz

class schedule:
    def __init__(self):
        self.daylist=['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье']
        self.monthlist=['января','февраля','марта','aпреля','мая','июня','июля','августа','сентября','октября','ноября','декабря']
        self.file_name=""
        self.list_name=""
        self.faculty=""

    def time_converter(self):
        utc_dt = datetime.datetime.now(datetime.timezone.utc)
        PST = pytz.timezone('Asia/Tashkent')
        return utc_dt.astimezone(PST)

    def checker_on_date(self,s):
        s2=""
        m=0
        p=""

        for k in range(len(s)):
            if s[k].isdigit() or s[k]==".":
                if m==0:
                    for t in range(k-1,0,-1):
                        if s[t]=="(":
                            break

                        if len(s[t].strip())>0:
                            p=s[t]+p

                    m=1

                s2=s2+s[k]

        if len(s2.strip())==0:
            return 2

        if p=="до":
            c=s2.split(".")
            a=int(datetime.datetime(2000+int(c[2]),int(c[1]),int(c[0])).strftime('%j'))
            b=int(self.time_converter().strftime("%j"))

            if b<a:
                return 1
            else:
                return 0

        if p=="с":
            c=s2.split(".")
            a=int(datetime.datetime(2000+int(c[2]),int(c[1]),int(c[0])).strftime('%j'))
            b=int(self.time_converter().strftime("%j"))

            if b+8>a:
                return 1
            else:
                return 0

        return 2

    def calc_day(self):
        b=self.time_converter()
        curday=b.weekday()
        days=[]

        for i in range(7):
            c=int(curday)
            dt=(b-datetime.timedelta(days=c-i)).strftime('%d %m %y')

            a=dt.split()[0]
            d=dt.split()[1]

            dt_=a+" "+str(self.monthlist[int(d)-1])
            days.append([dt_,dt])

        return days

    def union(self,df):
        temp=[]
        tmp=[]
        str1=""
        info=[]

        for x in df:
            temp.append(df[x])

        ##len(temp): 13 - если 2 группы. 16 - если 3 группы

        for i,x in enumerate(temp[3][6:]):
            for m in range(len(temp)):
                for j,y in enumerate(temp[m][6:]):
                    if j==i:
                        str1=str1+"\t"+str(y)
                        break

            str2=str1.split("\t")
            tmp.append(str2)
            str1=""

        info=tmp[0]
        mode_del=0

        for i in range(len(tmp)):
            if i>29:
                for k in range(len(tmp[i])):
                    if tmp[i][k]!="" and "мигалка" in tmp[i][k]:
                        tmp[i]=[]
                        mode_del=1
                        break

            if i>36 or i==0 or i==1 or i==2 or mode_del==1:
                tmp[i]=[]

        for i in range(len(tmp)-1,-1,-1):
            tmp[i]=tmp[i][2:]  ##удаляем пустые строчки
            tmp[i]=tmp[i][:-3] ##удаляем данные для москвичей

            if tmp[i]==[]:
                del tmp[i]

        '''разбиение по дням'''
        day_sorted_info=[]
        for y in range(7):
            day_sorted_info.append([self.daylist[y]])

        current_index=0
        for i in range(len(tmp)):
            if tmp[i][0]!="":
                  for k in range(len(day_sorted_info)):
                    if tmp[i][0]==day_sorted_info[k][0]:
                        current_index=k
                        break

            tmp[i]=tmp[i][1:]
            day_sorted_info[current_index].append(tmp[i])

        return day_sorted_info,info



    def getinfo(self,group_name):
        '''считываем из папки'''

        p=os.scandir("schedule_dir")
        for x in p:
            self.file_name=x

        '''текущая дата'''
        curyear=int(self.time_converter().timetuple()[0])
        curmonth=int(self.time_converter().timetuple()[1])

        group_number=group_name[1]
        year=int(group_name[-2:])

        '''в сентябре курсы сдвигаются'''
        if curmonth<9:
            course=str(curyear-2000-year)
        else:
            course=str(curyear-1999-year)

        if group_number=="М":
            if group_name[0]=="М":
                self.list_name="Магистратура ПМиИ "+course+" курс"

            if group_name[0]=="П":
                self.list_name="Магистратура Психология "+course+" курс"

        if group_number!="М":
            if group_name[0]=="М":
                self.list_name="ПМиИ "+course+" курс"

            if group_name[0]=="П":
                self.list_name="Психология "+course+"-курс"

            if group_name[0]=="Р":
                self.list_name="РиСО "+course+" курс"

            if group_name[0]=="Ф":
                self.list_name="Филология "+course+" курс"

    def pretty_write(self,lst,mode):
        if mode==1:
             b=self.time_converter()
             curday=int(b.weekday())-1
             dt=(b+datetime.timedelta(days=1)).strftime('%d %m %y')

             a=dt.split()[0]
             d=dt.split()[1]
             dt_=a+" "+str(self.monthlist[int(d)-1])


        s=""
        s_temp=""

        for i in range(len(lst)):
            if mode==1 and dt_==lst[i][0].split('.')[1][1:]:
                if lst[i][1]!=[]:
                    s_temp=s_temp+lst[i][0]+"\n"

            if mode==0:
                if lst[i][1]!=[]:
                    s_temp=s_temp+lst[i][0]+"\n"

            for j in range(len(lst[i][1])):
                if lst[i][1][j][2]!="":
                    if mode==1 and dt_==lst[i][0].split('.')[1][1:]:
                        s_temp=s_temp+" ".join(lst[i][1][j])+"\n"

                    if mode==0:
                        s_temp=s_temp+" ".join(lst[i][1][j])+"\n"

            if mode==0:
                if s_temp.strip()!=lst[i][0]:
                   s=s+s_temp+"\n"

                s_temp=""

        if mode==1 and s_temp.split('.')[1][1:].strip()==dt_:
            s_temp="Занятий "+dt_+" нет"
            return s_temp

        if mode==0:
            return s

        return s_temp


    def main(self,group_name,tomorrow_or_all):
        self.getinfo(group_name)
        xlsx=pd.ExcelFile(self.file_name)
        df=pd.read_excel(xlsx,self.list_name,keep_default_na=False)
        self.data,info=self.union(df) ##получили расписание в приемлимом виде, разделенное по дням

        cur_list=[]
        for i in range(7):
            cur_list.append([[],[]])

        ##1 группа 3,4,5
        ##2 группа 6,7,8
        ##3 группа 9,10,11

        group_number=group_name[1]

        if group_number=="1" or group_number=="М":
            info=info[5:]
            info=info[0:3]
            start=2
            end=5

        if group_number=="2":
            info=info[5:]
            info=info[3:6]
            start=5
            end=8

        if group_number=="3":
            info=info[5:]
            info=info[6:9]
            start=8
            end=11

        ##относительно сегодняшнего дня заполняем остальные даты дней недели##

        d=self.calc_day()
        for i in range(len(self.data)):
            cur_list[i][0]=self.data[i][0]+". "+d[i][0] ##день недели + текущая дата

        for i in range(len(self.data)):
            for j in range(1,len(self.data[i])):
                a=self.data[i][j][0:2] ##номер пары, время начала пары
                b=self.data[i][j][start:end] ##название пары, преподаватель, кабинет

                '''анализируем что написано в названии предмета'''
                '''1. если там больше одной открывающей скобки (если меньше, то это (семинар),(лекция) и т.д'''

                if b[0].count("(")+1:
                    ## через / может быть указано дата конца одного предмета и начало другого

                    if "/" in b[0]:
                        c=b[0].split("/")
                        v1=self.checker_on_date(c[0])
                        v2=self.checker_on_date(c[1])

                        if v1=="1": ##до текущей даты
                            b[0]=c[0] ##c текущей даты

                        if v2=="1":
                            b[0]=c[1]

                    else:
                        v=self.checker_on_date(b[0]) ##если текущая дата не наступила убираем ненужную информацию
                        if v==0:
                             for m in range(len(b)):
                                b[m]=""

                '''2. пары мигалки взависимости от четности недели'''
                if "(Ч)" in b[0] or "(Н)" in b[0]:
                    ##по дате узнаем номер дня в году. Делим на кол-во дней в неделе и определяем четность
                    c=d[i][1].split()
                    r=datetime.datetime(2000+int(c[2]),int(c[1]),int(c[0])).strftime('%j')
                    p=int((float(r)/7))%2

                    ##только один из параметров
                    if "(Ч)" in b[0] and not "(Н)" in b[0] and p!=0:
                        for m in range(len(b)):
                            b[m]=""

                    if "(Н)" in b[0] and not "(Ч)" in b[0] and p==0:
                        for m in range(len(b)):
                            b[m]=""

                    ##оба параметра
                    if "(Н)" in b[0] and "(Ч)" in b[0]:
                        g=b[0].split('/')
                        h=b[1].split('/')

                        if len(h)==1: ##случай если пары ведет один преподаватель (чередуется семинар и лекция)
                            if "(Ч)" in g[1]:
                                m=g[0].replace("(лекция)","").replace("(семинар)","").replace("(Н)","").strip()
                                g[1]=g[1].replace("(Ч)","(Ч)"+m)

                            if "(Н)" in g[1]:
                                m=g[0].replace("(лекция)","").replace("(семинар)","").replace("(Ч)","").strip()
                                g[1]=g[1].replace("(Н)","(Н)"+m)

                            h=[h[0],h[0]]

                        if p==0: ##четная
                            if not "(Ч)" in g[0]:
                                b=[g[1],h[1],b[2]]
                            else:
                                b=[g[0],h[0],b[2]]

                        if p==1: ##нечетная
                            if not "(Н)" in g[0]:
                                b=[g[0],h[0],b[2]]
                            else:
                                b=[g[1],h[1],b[2]]

                cur_list[i][1].append(a+b)

        ##0 - все расписание
        ##1 - завтра

        if tomorrow_or_all=="1":
            s1=self.pretty_write(cur_list,1)
        else:
            s1=self.pretty_write(cur_list,0)

        s2=" ".join(info)
        s1=s2+'\n\n'+s1.strip()
        return s1
