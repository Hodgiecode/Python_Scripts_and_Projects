#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "03_1_02.h"

int task_03_1_02(char *filename)
{
	int i=0;
	double a=0, b=0;  

	FILE *FILE, *fm;

	FILE=fopen(filename , "r");
	
	if (FILE!=NULL)
	{
		while(fscanf(FILE, "%lf", &a)==1)
		{
			b=b+a;
			i++;
		}
		a=b/i;
	}

	fm=fopen("03_1_02out.txt", "w");

	if (FILE!=NULL)
	{
 fprintf (fm ,"%lf", a);
	}

	fclose (FILE);
	fclose (fm);

	return 0;
}