#include <stdio.h>
#include <string.h>
#include "03_1_17.h"

int main(int argc, char **argv){
  char filename[256];
  if (argc < 2){
    printf("Input file name : ");
    scanf("%s", filename);
  }
  else{
    strcpy(filename, argv[1]);
  }
  task_03_1_17(filename);
  return 0;
}