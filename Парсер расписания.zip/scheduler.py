import datetime
import pandas as pd
import os

class schedule:
    def __init__(self):
        self.daylist=['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье']
        self.monthlist=['января','февраля','марта','aпреля','мая','июня','июля','августа','сентября','октября','ноября','декабря']
        self.file_name=""
        self.list_name=""
        self.faculty=""

    def calc_day(self):
        b=datetime.datetime.today()
        curday=b.weekday()
        days=[]

        for i in range(7):
            c=int(curday)
            dt=(b-datetime.timedelta(days=c-i)).strftime('%d %m %y')
            
            a=dt.split()[0]
            d=dt.split()[1]
            
            dt_=a+" "+str(self.monthlist[int(d)-1])
            days.append([dt_,dt])

        return days

    def union(self,df):
        temp=[]
        tmp=[]
        str1=""
        info=[]
       
        for x in df:
            temp.append(df[x])

        ##len(temp): 13 - если 2 группы. 16 - если 3 группы

        for i,x in enumerate(temp[3][6:]):
            for m in range(len(temp)):
                for j,y in enumerate(temp[m][6:]):
                    if j==i:
                        str1=str1+"\t"+str(y)
                        break

            str2=str1.split("\t")
            tmp.append(str2)
            str1=""

        info=tmp[0]
        
        for i in range(len(tmp)):
            if i>27 or i==0 or i==1 or i==2:
                tmp[i]=[]

        for i in range(len(tmp)-1,-1,-1):
            tmp[i]=tmp[i][2:]  ##удаляем пустые строчки
            tmp[i]=tmp[i][:-3] ##удаляем данные для москвичей
            
            if tmp[i]==[]:
                del tmp[i]

        '''разбиение по дням'''
        day_sorted_info=[]
        for y in range(7):
            day_sorted_info.append([self.daylist[y]])

        current_index=0
        for i in range(len(tmp)):
            if tmp[i][0]!="":
                  for k in range(len(day_sorted_info)):
                    if tmp[i][0]==day_sorted_info[k][0]:
                        current_index=k
                        break

            tmp[i]=tmp[i][1:]
            day_sorted_info[current_index].append(tmp[i])

        return day_sorted_info,info
                    


    def getinfo(self,group_name):
        '''считываем из папки'''
        p=os.scandir("schedule_dir")
        for x in p:
            self.file_name=x

        '''текущая дата'''
        curyear=int(datetime.datetime.today().timetuple()[0])
        curmonth=int(datetime.datetime.today().timetuple()[1])

        group_number=group_name[1]
        year=int(group_name[-2:])
       
        '''в сентябре курсы сдвигаются'''
        if curmonth<9:
            course=str(curyear-2000-year)
        else:
            course=str(curyear-1999-year)

        if group_number=="М":
            if group_name[0]=="М":
                self.list_name="Магистратура ПМиИ "+course+" курс"

            if group_name[0]=="П":
                self.list_name="Магистратура Психология "+course+" курс"
        
        if group_number!="М":
            if group_name[0]=="М":
                self.list_name="ПМиИ "+course+" курс"

            if group_name[0]=="П":
                self.list_name="Психология "+course+"-курс"

    def pretty_write(self,lst,mode):
        if mode==1:
             b=datetime.datetime.today()
             curday=int(b.weekday())
             dt=(b+datetime.timedelta(days=curday)).strftime('%d %m %y')
            
             a=dt.split()[0]
             d=dt.split()[1]
             dt_=a+" "+str(self.monthlist[int(d)-1])
             
        s=""
        for i in range(len(lst)):
            if mode==1 and dt_==lst[i][0].split('.')[1][1:]:
                s=s+lst[i][0]+"\n"

            if mode==0:
                s=s+lst[i][0]+"\n"
               
            for j in range(len(lst[i][1])):
                if lst[i][1][j][2]!="":
                    if mode==1 and dt_==lst[i][0].split('.')[1][1:]:
                        s=s+" ".join(lst[i][1][j])+"\n"

                    if mode==0:
                        s=s+" ".join(lst[i][1][j])+"\n"

            if mode==0:
                s=s+"\n"

        return s
        

    def extract_data(self,group_name,tomorrow_or_all):
        self.getinfo(group_name)
        xlsx=pd.ExcelFile(self.file_name)
        df=pd.read_excel(xlsx,self.list_name,keep_default_na=False)
        self.data,info=self.union(df) ##получили расписание в приемлимом виде, разделенное по дням

        cur_list=[]
        for i in range(7):
            cur_list.append([[],[]])
            
        ##1 группа 3,4,5 
        ##2 группа 6,7,8
        ##3 группа 9,10,11

        group_number=group_name[1]
        
        if group_number=="1" or group_number=="М":
            info=info[5:]
            info=info[0:3]
            start=2
            end=5

        if group_number=="2":
            info=info[5:]
            info=info[3:6]
            start=5
            end=8

        if group_number=="3":
            info=info[5:]
            info=info[6:9]
            start=8
            end=11

        d=self.calc_day()
        for i in range(len(self.data)):
            cur_list[i][0]=self.data[i][0]+". "+d[i][0]

        for i in range(len(self.data)):
            for j in range(1,len(self.data[i])):
                a=self.data[i][j][0:2]
                b=self.data[i][j][start:end]
                
                if "(Ч)" in b[0] or "(Н)" in b[0]:
                    c=d[i][1].split()
                    r=datetime.datetime(2000+int(c[2]),int(c[1]),int(c[0])).strftime('%j')
                    p=int((float(r)/7))%2

                    if "(Ч)" in b[0] and not "(Н)" in b[0] and p!=0:
                        for m in range(len(b)):
                            b[m]=""

                    if "(Н)" in b[0] and not "(Ч)" in b[0] and p==0:
                        for m in range(len(b)):
                            b[m]=""

                    if "(Н)" in b[0] and "(Ч)" in b[0]:
                        g=b[0].split('/')
                        h=b[1].split('/')

                        if len(h)==1:
                            if "(Ч)" in g[1]:
                                m=g[0].replace("(лекция)","").replace("(семинар)","").replace("(Н)","").strip()
                                g[1]=g[1].replace("(Ч)","(Ч)"+m)

                            if "(Н)" in g[1]:
                                m=g[0].replace("(лекция)","").replace("(семинар)","").replace("(Ч)","").strip()
                                g[1]=g[1].replace("(Н)","(Н)"+m)
                                                  
                            h=[h[0],h[0]]
                            
                        if p==0:
                            if not "(Ч)" in g[0]:
                                b=[g[1],h[1],b[2]]
                            else:
                                b=[g[0],h[0],b[2]]

                        if p==1:
                            if not "(Н)" in g[0]:
                                b=[g[0],h[0],b[2]]
                            else:
                                b=[g[1],h[1],b[2]]

                        
                        
                            
                cur_list[i][1].append(a+b)

        ##0 - все расписание
        ##1 - завтра

        if tomorrow_or_all=="1":
            s1=self.pretty_write(cur_list,1)
        else:
            s1=self.pretty_write(cur_list,0)
            
        s2=" ".join(info)
        s1=s2+'\n\n'+s1
        return s1
        
        
A=schedule()
#A.extract_data('М1-20','0')

