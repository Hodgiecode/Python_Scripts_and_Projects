
# coding: utf-8

# In[10]:


import numpy as np

# Оригинал https://stackoverflow.com/questions/5347091/slicing-nested-list

class MyClass:
    def __init__(self, array, axis = None, dtype = None):
        self.array = array
        self.axis = axis
        self.temp = []

        if dtype == None:
            self.dtype = float
        else:
            self.dtype = dtype
            
    ### работа с axis
    def array_items(self, array, i_zero = []):
        try:
            for i, a_i in enumerate(array):
                yield from self.array_items(a_i, i_zero + [i])
        except:
            yield i_zero, array
        
    def array_shape(self, array):
        shape = [];
        while True:
            try:
                axis_length = 0;
                for a_i in array: axis_length = axis_length + 1

                array = a_i
                shape.append(axis_length)
            except:
                return shape

    def array_zeros(self, shape):
        if len(shape) == 0: return 0

        if len(shape)!= 0:
            a_zero = shape[0]
            shape  = shape[1:]
            return list(self.array_zeros(shape) for _ in range(a_zero))

    def flatten(self, l):
        for i, elem in enumerate(l):
            if isinstance(elem, list):
                l[i] = self.flatten(elem)
            else:
                self.temp.append(elem)
                
        return l

    ## преобразуем значения в соответствующий тип
    def dtype_converter(self, l):
        for i, elem in enumerate(l):
            if isinstance(elem, list):
                l[i] = self.dtype_converter(elem)
            else:
                if self.dtype == int: l[i] = int(l[i])
                if self.dtype == float: l[i] = float(l[i])
                
        return l

    ## проверка что среди значений нет строк
    def data_checker(self):
        self.flatten(self.array)

        if self.temp == []: return -1
        
        for i in range(len(self.temp)):
            if isinstance(self.temp[i], str): return -2

        self.temp = []
        return 0

    def axis_none(self):
        self.flatten(self.array)
        result = sum(self.temp) / len(self.temp)
        return result

    ## axis = 0 || axis = 1
    def array_summ(self, array, index, a=1, b=0):
        for i in index[:-1]:
            array = array[i]

        array[index[-1]] = a * array[index[-1]] + b

    def axis_zero_one(self):
        in_shape = self.array_shape(self.array)
        temp = self.array_zeros(in_shape[:self.axis] + in_shape[self.axis + 1:])
        
        for elem in self.array_items(self.array):
            index, value = elem
            self.array_summ(temp, index[:self.axis] + index[self.axis + 1:], 1, value / in_shape[self.axis])

        self.dtype_converter(temp)
        return temp

    def mean(self):
        if self.data_checker() == -1: return "Empty list"
        if self.data_checker() == -2: return "Can work only with int or float"
            
        if self.axis == None: return self.axis_none()

        return self.axis_zero_one()
    
def main():
    test0 = [1, 2]
    test1 = [[1,2],[3,4]]
    test2 = [[[1],[2]]]
    test3 = [[[1,4],[2,3]]]
    test4 = [[[[1,2,3],[4,5,6]]],[[[2,2,3],[4,5,6]]]]
    test5 = [1, 2, 3]
    test6 = [[[]]]
    test7 = [['1', 2]]
    
    print("Test_1")
    A = MyClass(test1, axis = 0, dtype = int).mean()
    print("Axis 0", A, "/", np.mean(test1, axis = 0, dtype = int))
    
    A = MyClass(test1, axis = 1, dtype = int).mean()
    print("Axis 1", A, "/", np.mean(test1, axis = 1, dtype = int))
    print()
    
    print("Test_2")
    A = MyClass(test2, axis = 0, dtype = float).mean()
    print("Axis 0", A, "/", np.mean(test2, axis = 0, dtype = float))
   
    A = MyClass(test2, axis = 1, dtype = float).mean()
    print("Axis 1", A,"/", np.mean(test2, axis = 1, dtype = float))
    print()
    
    print("Test_3")
    A = MyClass(test3, axis = 0, dtype = int).mean()
    print("Axis 0", A,"/", np.mean(test3, axis = 0, dtype = int))
   
    A = MyClass(test3, axis = 1, dtype = int).mean()
    print("Axis 1", A,"/", np.mean(test3, axis = 1, dtype = int))
    print()
    
    print("Test_4")
    A = MyClass(test4).mean()
    print("Axis = None", A,"/",np.mean(test4))
    print()
    
    print("Test_5")
    A = MyClass(test5).mean()
    print(A,"/", np.mean(test5))
    print()

    print("Test_6")
    A = MyClass(test6).mean()
    print(A)
    print()
    
    print("Test_7")
    A = MyClass(test7).mean()
    print(A)
    print()

    
main()

