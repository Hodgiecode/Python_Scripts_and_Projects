#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "03_1_02_header.h"

int main()
{
	double otv=0;
	int f;
	FILE *fm;

 f = 03_1_02_SA ( &otv);

	fm=fopen("03_1_02_out.txt", "w");

	if (f==-2)
		fprintf(fm, "Can't open file\n");

	else if (f==-1)
		fprintf(fm, "File is empty\n");    
	
	fclose (fm);
	return 0;
}